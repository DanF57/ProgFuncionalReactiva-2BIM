package paquete01.semana11;

import java.util.List;
import java.util.concurrent.SubmissionPublisher;

public class App {
    public static void main(String[] args) throws InterruptedException {
        SubmissionPublisher<String> publisher = new SubmissionPublisher<>();
        //Crear el subscriber y la subscripcion
        PrinterSubscriber printer  = new PrinterSubscriber();

        //Subscripcion
        publisher.subscribe(printer);

        List<String> items = List.of("1", "x", "2", "x", "3", "x");
        //Enviar los datos a los subscriptores
        items.forEach(publisher::submit);

       Thread.sleep(1 * 1000);

       publisher.close();

    }
}

